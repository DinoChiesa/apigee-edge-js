 // deriveKeyId.js
// ------------------------------------------------------------------
// Maps the KeyId to Apigee Key Id
// created: Tue Mar  7 10:33:34 2017
// last saved: <2017-March-07 11:08:14>

  try {
    var keyValue=context.getVariable("httpsig_keyId").toUpperCase()
    
    switch(keyValue)
    {
      case "QA:QA_CDX-NPROD-20170313": 
          keyMask = "CDXQA20170313";
          break;
      case "S-HAWS:HAWS_CDX-NPROD-20170315":
          keyMask = "CDXNPRODSHAWS20170315";
      break;
      default:
        keyMask = "INVALID_KEY";
    }
        context.setVariable("httpsig_keyId", keyMask);
    }
  catch (exc1) {
    context.setVariable(destVarName, JSON.stringify({error: 'invalid JSON'}));
  } 