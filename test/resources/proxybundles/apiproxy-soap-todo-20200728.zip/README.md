# SOAP Facade over REST API

This is an API Proxy configuration for Apigee Edge that exposes a SOAP facade over an existing REST / JSON API,
https://jsonplaceholder.typicode.com/todos .

## Deploying

Import the apiproxy-bundle.zip into your org, and then deploy it into an environment.

## Invoking it

There is no WSDL. The SOAP request must be formatted like this:
```xml
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope/">
  <soap:Body>
    <m:GetTodo xmlns:m="https://jsonplaceholder.typicode.com/todos">
      <m:ItemId>5</m:ItemId>
    </m:GetTodo>
  </soap:Body>
</soap:Envelope>
```

For example, here's how to send a request into the proxy:

```
ORG=myorg
ENV=test
curl -i https://${ORG}-${ENV}.apigee.net/soaptodo/soap1.2 -X POST \
 -H content-type:application/xml \
 -d '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope/">
       <soap:Body>
         <m:GetTodo xmlns:m="https://jsonplaceholder.typicode.com/todos">
           <m:ItemId>5</m:ItemId>
         </m:GetTodo>
       </soap:Body>
     </soap:Envelope>'
```

The response from that:

```
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope/">
  <soap:Body>
    <m:GetTodoResponse xmlns:m="https://jsonplaceholder.typicode.com/todos">
      <m:Completed>false</m:Completed>
      <m:UserId>1</m:UserId>
      <m:Id>5</m:Id>
      <m:Title>laboriosam mollitia et enim quasi adipisci quia provident illum</m:Title>
    </m:GetTodoResponse>
  </soap:Body>
</soap:Envelope>
```


## How it works

The proxy uses an ExtractVariables policy to extract the SOAP element, and verify it.
It then uses another ExtractVariables policy to extract the parameters contained within the request element (GetTodo).

It then uses JavaScript to construct a GET request with the proper URI for the backend.

And then ExtractVariables and AssignMessage to create a SOAP response from that.

There's a little bit of validation in the proxy, to check for invalid requests and invalid namespaces in the SOAP Envelope, and so on.

There is no WSDL.


## Disclaimer

This is just an example. This is not an official Google product nor is it part of an official Google product.

## Copyright

Copyright (c) 2018 Google LLC.

## License

This material is licensed under the [Apache 2.0 License](LICENSE).
