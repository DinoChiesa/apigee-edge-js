// construct-Request.js

context.setVariable('target.copy.pathsuffix', false);
context.setVariable('message.verb', 'GET');
context.setVariable('message.content', '');
var originalUrl = context.getVariable('target.url');
var todoItem = context.getVariable('soap.itemId');
context.setVariable('target.url', originalUrl + '/todos/' + todoItem);
